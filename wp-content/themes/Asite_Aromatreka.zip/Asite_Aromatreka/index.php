<?php get_header(); ?>
    <!-- Section Menu -->
        <?php get_template_part('section-index/menu'); ?>
    <!--END Section Menu -->
    <!-- Section Map -->
            <?php get_template_part('section-index/map'); ?>
    <!-- END Section Map -->
<?php get_footer(); ?>