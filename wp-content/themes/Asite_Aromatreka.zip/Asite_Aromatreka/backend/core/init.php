<?php
/**
 * File Name: init.php
 * Date: 28-08-2016
 * Time: 12:21
 * Description: File init core Theme option
 */
require_once dirname( __FILE__ ) . '/class-tgm-plugin-activation.php';
require_once dirname( __FILE__ ) . '/plugins.php';
require_once dirname(__FILE__).'/options.php';
?>