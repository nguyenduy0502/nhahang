<?php
/*
Plugin Name: CustomPostRestaurant
Plugin URI: http://asite.it
Description: Custom post
Author: asite
Author URI: http://asite.it
Version: 1.3
Text Domain: asite
*/
require_once('TypeFood/constructor-food.php');
require_once('TypeFood/constructor-taxonomy.php');
require_once('TypeFood/meta-box-food.php');
?>