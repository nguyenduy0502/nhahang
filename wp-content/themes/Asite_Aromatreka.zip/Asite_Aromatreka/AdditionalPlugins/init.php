<?php
/**
 * File Name: main.php
 * Date: 08-05-2017
 * Time: 16:08
 * Description:
 */


require_once dirname(__FILE__) . '/FoodRestaurant/main.php';
require_once dirname(__FILE__) . '/MenuRestaurant/main.php';
?>